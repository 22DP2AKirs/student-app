package rvt;

public class Student {
    public String name;
    public String surname;
    public String email;
    public String group;


    public Student(String name, String surname, String email, String group) {
        this.name = name;
        this.surname = surname;
        this.email = email;
        this.group = group;
    }
}
